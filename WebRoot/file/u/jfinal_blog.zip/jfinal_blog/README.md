jfinal_blog
============

用jfinal开发的一个个人博客系统

